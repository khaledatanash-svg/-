const navItems = [
  { page: "home", label: "الرئيسية", href: "index.html" },
  { page: "news", label: "أخبار", href: "news.html" },
  { page: "culture", label: "ثقافة", href: "culture.html" },
  { page: "arts", label: "فنون", href: "arts.html" },
  { page: "word", label: "كلمة اليوم", href: "word.html" },
  { page: "magazine", label: "مجلة حوارة الثقافية", href: "magazine.html" },
  { page: "photos", label: "صور", href: "photos.html" },
  { page: "heritage", label: "من تراث حوارة", href: "heritage.html" },
  { page: "educators", label: "شخصيات تربوية من حوارة", href: "educators.html" }
];

const pageData = {
  news: {
    eyebrow: "نافذة الخبر",
    title: "أخبار",
    intro: "متابعة هادئة لما يجري في المنارة: لقاءات، مبادرات، دعوات للمشاركة، وأخبار المجتمع الثقافي في حوارة.",
    highlightTitle: "إطلاق موقع منارة حوارة الثقافية",
    highlightText: "بوابة جديدة تجمع الصفحات التحريرية والذاكرة البصرية في مكان واحد، وتفتح الباب أمام مشاركة الأهالي والمهتمين.",
    cards: [
      ["خبر", "لقاء قرائي شهري", "جلسة مفتوحة حول كتاب الشهر، مع مساحة للنقاش وتبادل الترشيحات."],
      ["إعلان", "دعوة للكتابة", "تستقبل المنارة مقالات قصيرة وصورًا ومواد تراثية للنشر في الصفحات الثقافية."],
      ["متابعة", "أرشفة الفعاليات", "بدء ترتيب سجل رقمي للنشاطات الثقافية والفنية القادمة والسابقة."],
      ["مجتمع", "مساحة للشباب", "زاوية جديدة لكتابات الطلبة واليافعين، ضمن إشراف تحريري يحافظ على جودة النص."],
      ["تعاون", "شراكات ثقافية", "فتح باب التعاون مع المدارس والمكتبات والفرق الفنية لإثراء البرنامج العام."],
      ["تنويه", "روزنامة الفعاليات", "سيتم تحديث جدول الفعاليات بشكل دوري لتسهيل متابعة النشاطات."],
    ]
  },
  culture: {
    eyebrow: "قراءة ومعرفة",
    title: "ثقافة",
    intro: "مقالات وقراءات وحوارات قصيرة تمنح صوتًا للمكان، وتربط الذاكرة اليومية بالمعرفة والفكر.",
    highlightTitle: "ملف مفتوح: المكان في الذاكرة",
    highlightText: "سلسلة نصوص تستعيد العلاقة بين الحارة والبيت والمدرسة والساحة، وكيف تتحول التفاصيل الصغيرة إلى ذاكرة مشتركة.",
    cards: [
      ["مقال", "لماذا نكتب عن المكان؟", "الكتابة عن المكان ليست حنينًا فقط، بل طريقة لفهم التحولات وحفظ التفاصيل."],
      ["قراءة", "كتاب على الطاولة", "نافذة شهرية لقراءة كتاب ومناقشة أثره على القارئ والمجتمع."],
      ["حوار", "أسئلة مع كاتب محلي", "صيغة قصيرة تعرف القارئ بأصحاب التجارب الثقافية في حوارة."],
      ["لغة", "مفردات من الذاكرة", "كلمات محكية وقصصها، بين الاستعمال اليومي والمعنى الاجتماعي."],
      ["رأي", "الثقافة والعمل الأهلي", "كيف تصبح المبادرات الصغيرة نواة لحياة ثقافية مستمرة؟"],
      ["ملف", "المدرسة بوصفها ذاكرة", "مواد تجمع شهادات وصورًا وذكريات عن التعليم في حوارة."],
    ]
  },
  arts: {
    eyebrow: "مساحة إبداع",
    title: "فنون",
    intro: "صفحة للفنون البصرية والموسيقى والمسرح والخط، تتيح عرض التجارب المحلية وتشجيع الورش والمعارض الصغيرة.",
    highlightTitle: "معرض افتراضي لأعمال اليافعين",
    highlightText: "مساحة دورية لعرض رسومات وصور وأعمال يدوية، مع احترام حقوق أصحاب الأعمال وذكر أسمائهم عند النشر.",
    cards: [
      ["فن بصري", "لوحة من الحارة", "دعوة لرسم مشاهد من تفاصيل حوارة اليومية: بيت، شجرة، نافذة، أو طريق."],
      ["موسيقى", "أمسية أصوات محلية", "برنامج مقترح يجمع العزف والغناء والقراءات القصيرة في أمسية واحدة."],
      ["مسرح", "مشهد قصير", "تجارب مسرحية مدرسية وشبابية قابلة للتوثيق والعرض في المنارة."],
      ["خط", "ورشة الخط العربي", "تعريف بأساسيات الخط وتطبيقات بسيطة على عناوين من الذاكرة المحلية."],
      ["حرف", "يد تصنع الجمال", "أعمال يدوية وحرفية من البيت والمدرسة والمناسبات الاجتماعية."],
      ["نقد", "قراءة عمل فني", "زاوية لطيفة تشرح العمل الفني دون تعقيد، وتفتح حوارًا حول المعنى والشكل."],
    ]
  },
  heritage: {
    eyebrow: "ذاكرة المكان",
    title: "من تراث حوارة",
    intro: "مواد تراثية تحفظ الحكاية الشعبية، المفردة القديمة، الأغنية، الطبخة، وأشكال الحياة التي صنعت ذاكرة الناس.",
    highlightTitle: "دفتر التراث الشعبي",
    highlightText: "مساحة لتوثيق القصص والأمثال والمناسبات والعادات كما يرويها أهلها، مع عناية بسياق الرواية واسم الراوي عند توفره.",
    cards: [
      ["حكاية", "قصة من المضافة", "حكايات قصيرة متداولة في الجلسات، تكتب بصيغة تحفظ روح الراوي."],
      ["مفردة", "كلمة من البيت القديم", "جمع كلمات من الحياة اليومية وشرح استخدامها في سياقها."],
      ["غناء", "أهازيج ومناسبات", "توثيق أغان وأهازيج ارتبطت بالموسم والعمل والفرح."],
      ["طعام", "وصفة من الذاكرة", "أطباق بيتية مرتبطة بالمواسم والعائلة والضيافة."],
      ["لباس", "تفاصيل الزي", "صور ونصوص قصيرة عن الأزياء التقليدية وتفاصيلها."],
      ["أدوات", "أشياء كانت هنا", "تعريف بأدوات منزلية وزراعية وتعليمية من الذاكرة المحلية."],
    ]
  }
};

const magazineIssues = [
  ["العدد الأول", "المكان والذاكرة", "ملف افتتاحي عن حوارة كما تظهر في النصوص والصور والشهادات."],
  ["ملف خاص", "التعليم والرواد", "باب مخصص للمعلمين والمعلمات والتجارب المدرسية المؤثرة."],
  ["باب القراء", "نصوص قصيرة", "قصائد، خواطر، ورسائل ثقافية تصل إلى هيئة التحرير."],
  ["الفنون", "ألوان وأصوات", "ملف للأعمال الفنية والمعارض والورش الشبابية."],
  ["تراث", "حكايات من البيوت", "مواد شفوية مكتوبة بعناية لحفظ الذاكرة الشعبية."],
  ["صور", "ألبوم المنارة", "لقطات من الفعاليات والمناسبات والمواد الأرشيفية."],
];

const galleryItems = [
  ["heritage", "visual-lanes", "أزقة وبيوت", "ملامح من المكان كما تتذكرها العين والذاكرة."],
  ["arts", "visual-stage", "أمسية فنية", "مساحة للعرض الموسيقي والمسرحي والقراءات."],
  ["culture", "visual-books", "رف الكتب", "زاوية القراءة واللقاءات الثقافية الشهرية."],
  ["heritage", "visual-harvest", "موسم وذاكرة", "توثيق بصري للعادات والمواسم والعمل الجماعي."],
  ["arts", "visual-stage", "ورشة إبداع", "مشاهد من الرسم والخط والحرف اليدوية."],
  ["culture", "visual-books", "مائدة حوار", "صور من اللقاءات الثقافية والنقاشات العامة."],
];

const educatorCards = [
  ["بطاقة شخصية تربوية", "اسم المعلم أو المعلمة", "نبذة موجزة عن المسيرة التعليمية، المدرسة، السنوات، والأثر الذي تركته الشخصية في طلبتها."],
  ["شهادة طالب", "ذاكرة الصف", "مساحة لشهادات الطلاب والأهالي حول موقف أو درس أو قيمة تربوية بقيت في الذاكرة."],
  ["صورة أرشيفية", "المدرسة والجيل", "مكان مناسب لإضافة صورة قديمة مع تاريخها وأسماء الأشخاص الظاهرين فيها عند توفر الموافقة."],
  ["سيرة مختصرة", "الأثر المجتمعي", "توثيق المبادرات التعليمية، الأنشطة، أو الأعمال التطوعية التي ارتبطت بالشخصية التربوية."],
];

const wordBank = [
  {
    word: "منارة",
    text: "ليست الضوء وحده، بل المكان الذي يدل الناس على اتجاههم حين تختلط الطرق.",
    note: "كلمة تصلح عنوانًا لكل عمل ثقافي يحاول أن يفتح نافذة للآخرين."
  },
  {
    word: "ذاكرة",
    text: "ما يبقى من التفاصيل حين تمضي الأيام: صورة، رائحة خبز، جرس مدرسة، أو حكاية قصيرة.",
    note: "الذاكرة لا تحفظ الماضي فقط؛ تساعدنا على فهم الحاضر."
  },
  {
    word: "مضافة",
    text: "مكان للحديث والضيافة وتبادل الرأي، وفيها تتكون الحكايات قبل أن تصبح تراثًا.",
    note: "كل جلسة صادقة يمكن أن تكون بداية أرشيف."
  },
  {
    word: "أثر",
    text: "علامة يتركها الإنسان في غيره، وغالبًا لا يعرف حجمها إلا بعد وقت طويل.",
    note: "صفحة الشخصيات التربوية مبنية على فكرة الأثر."
  }
];

const app = document.querySelector("#app");
const currentPage = document.body.dataset.page || "home";

function buildNav() {
  const nav = document.querySelector("[data-nav]");
  if (!nav) return;
  nav.innerHTML = navItems.map((item) => {
    const active = item.page === currentPage ? " active" : "";
    return `<a class="${active.trim()}" href="${item.href}">${item.label}</a>`;
  }).join("");
}

function articleCard(item) {
  const [tag, title, text] = item;
  return `
    <article class="article-card">
      <div class="card-meta"><span class="tag">${tag}</span></div>
      <h3>${title}</h3>
      <p>${text}</p>
      <a class="button light" href="#">قراءة</a>
    </article>
  `;
}

function renderHero(data) {
  return `
    <section class="page-hero">
      <div class="container">
        <p class="eyebrow">${data.eyebrow}</p>
        <h1>${data.title}</h1>
        <p class="lead">${data.intro}</p>
      </div>
    </section>
  `;
}

function renderStandardPage(data) {
  return `
    ${renderHero(data)}
    <section class="section">
      <div class="container highlight">
        <article class="highlight-panel">
          <span class="tag">${data.title}</span>
          <h2>${data.highlightTitle}</h2>
          <p>${data.highlightText}</p>
        </article>
        <div class="side-list">
          ${data.cards.slice(0, 3).map((item) => `<a href="#"><strong>${item[1]}</strong><br><span>${item[2]}</span></a>`).join("")}
        </div>
      </div>
    </section>
    <section class="section band">
      <div class="container">
        <div class="section-header">
          <div>
            <h2>مواد مقترحة</h2>
            <p>بطاقات تحريرية جاهزة للتطوير وإضافة النصوص والصور الحقيقية لاحقًا.</p>
          </div>
        </div>
        <div class="card-grid">
          ${data.cards.map(articleCard).join("")}
        </div>
      </div>
    </section>
  `;
}

function renderHome() {
  const cards = navItems.filter((item) => item.page !== "home").map((item) => `
    <a class="quick-card" href="${item.href}">
      <span class="card-icon">${item.label.trim().slice(0, 1)}</span>
      <span>
        <h3>${item.label}</h3>
        <p>${homeText(item.page)}</p>
      </span>
    </a>
  `).join("");

  return `
    <section class="home-hero">
      <div class="container hero-content">
        <p class="eyebrow">من حوارة إلى كل محب للثقافة</p>
        <h1>منارة حوارة الثقافية</h1>
        <p class="lead">موقع يجمع الأخبار، الثقافة، الفنون، التراث، المجلة، الصور، وكلمة اليوم في واجهة عربية هادئة وواضحة.</p>
        <div class="button-row">
          <a class="button" href="news.html">تصفح الأخبار</a>
          <a class="button secondary" href="magazine.html">مجلة حوارة الثقافية</a>
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="section-header">
          <div>
            <h2>صفحات المنارة</h2>
            <p>الأقسام الأساسية التي طلبتها، مرتبة كصفحات مستقلة وجاهزة للتوسع بالمحتوى الحقيقي.</p>
          </div>
        </div>
        <div class="quick-grid">${cards}</div>
      </div>
    </section>
    <section class="section band compact">
      <div class="container highlight">
        <article class="highlight-panel">
          <span class="tag">افتتاحية</span>
          <h2>مساحة تحفظ الصوت والصورة</h2>
          <p>المنارة مصممة لتكون بيتًا رقميًا للخبر الثقافي، للمجلة، للألبوم، ولتوثيق الشخصيات والتجارب التي تستحق أن تبقى.</p>
        </article>
        <div class="side-list">
          <a href="word.html"><strong>كلمة اليوم</strong><br><span>كلمة قصيرة تتغير يوميًا من قاموس الذاكرة.</span></a>
          <a href="heritage.html"><strong>من تراث حوارة</strong><br><span>حكايات، مفردات، وأشياء من ذاكرة الناس.</span></a>
          <a href="educators.html"><strong>شخصيات تربوية من حوارة</strong><br><span>قوالب توثيق للسير والشهادات والصور.</span></a>
        </div>
      </div>
    </section>
  `;
}

function homeText(page) {
  const text = {
    news: "آخر المبادرات والفعاليات والدعوات.",
    culture: "مقالات وقراءات وحوارات قصيرة.",
    arts: "معارض وورش ومشاركات إبداعية.",
    word: "كلمة يومية من الذاكرة والمعنى.",
    magazine: "واجهة تحريرية للأعداد والملفات.",
    photos: "ألبوم بصري للفعاليات والأرشيف.",
    heritage: "حكايات ومفردات وعادات شعبية.",
    educators: "توثيق أثر المعلمين والمعلمات."
  };
  return text[page] || "";
}

function renderMagazine() {
  return `
    ${renderHero({
      eyebrow: "منبر تحريري",
      title: "مجلة حوارة الثقافية",
      intro: "صفحة مخصصة للأعداد والملفات والمواد التي تصدر باسم المجلة، مع بنية واضحة للأبواب التحريرية."
    })}
    <section class="section">
      <div class="container">
        <div class="magazine-cover">
          <span class="tag">غلاف العدد</span>
          <h2>العدد الافتتاحي: المكان والذاكرة</h2>
          <p>عنوان قابل للتبديل عند صدور العدد الحقيقي.</p>
        </div>
        <div class="issue-grid">
          ${magazineIssues.map(([tag, title, text]) => `
            <article class="issue-card">
              <span class="tag">${tag}</span>
              <h3>${title}</h3>
              <p>${text}</p>
              <a class="button light" href="#">فتح الملف</a>
            </article>
          `).join("")}
        </div>
      </div>
    </section>
  `;
}

function renderPhotos() {
  return `
    ${renderHero({
      eyebrow: "ألبوم المنارة",
      title: "صور",
      intro: "معرض بصري منظم يمكن أن يستقبل لاحقًا صور الفعاليات، الأرشيف، الأعمال الفنية، والمواد التراثية."
    })}
    <section class="section">
      <div class="container">
        <div class="gallery-toolbar">
          <div>
            <h2>ألبوم الصور</h2>
            <p>تصنيف سريع حسب نوع المادة البصرية.</p>
          </div>
          <div class="segmented" role="group" aria-label="تصفية الصور">
            <button class="active" type="button" data-gallery-filter="all">الكل</button>
            <button type="button" data-gallery-filter="culture">ثقافة</button>
            <button type="button" data-gallery-filter="arts">فنون</button>
            <button type="button" data-gallery-filter="heritage">تراث</button>
          </div>
        </div>
        <div class="gallery-grid" data-gallery>
          ${galleryItems.map(([type, visual, title, text]) => `
            <figure class="photo-card" data-gallery-item="${type}">
              <div class="gallery-visual ${visual}" aria-hidden="true"></div>
              <figcaption class="photo-caption">
                <div class="photo-meta"><span class="tag">${galleryLabel(type)}</span></div>
                <h3>${title}</h3>
                <p>${text}</p>
              </figcaption>
            </figure>
          `).join("")}
        </div>
      </div>
    </section>
  `;
}

function galleryLabel(type) {
  return {
    culture: "ثقافة",
    arts: "فنون",
    heritage: "تراث"
  }[type] || "صور";
}

function renderWord() {
  const word = pickDailyWord();
  const date = new Intl.DateTimeFormat("ar", { dateStyle: "full" }).format(new Date());
  return `
    ${renderHero({
      eyebrow: "نبضة يومية",
      title: "كلمة اليوم",
      intro: "مساحة قصيرة لكلمة واحدة كل يوم: معناها، ظلها الثقافي، وطريقة صغيرة للتأمل فيها."
    })}
    <section class="section">
      <div class="container daily-panel">
        <article class="daily-word">
          <span class="date">${date}</span>
          <h2 data-current-word>${word.word}</h2>
          <p>${word.text}</p>
          <button class="button secondary" type="button" data-copy-word>نسخ الكلمة</button>
        </article>
        <div class="daily-body">
          <h2>ظل الكلمة</h2>
          <p>${word.note}</p>
          <div class="card-grid">
            ${wordBank.map((item) => `
              <article class="quote-card">
                <blockquote>${item.word}</blockquote>
                <p>${item.text}</p>
              </article>
            `).join("")}
          </div>
        </div>
      </div>
    </section>
  `;
}

function pickDailyWord() {
  const day = Math.floor(new Date().setHours(0, 0, 0, 0) / 86400000);
  return wordBank[day % wordBank.length];
}

function renderEducators() {
  return `
    ${renderHero({
      eyebrow: "أثر التعليم",
      title: "شخصيات تربوية من حوارة",
      intro: "صفحة لتوثيق المعلمين والمعلمات وأصحاب الأثر التربوي، مع قوالب منظمة لإضافة السير والشهادات والصور الحقيقية."
    })}
    <section class="section">
      <div class="container">
        <div class="section-header">
          <div>
            <h2>بطاقات التوثيق</h2>
            <p>هذه البطاقات لا تفترض أسماء حقيقية، بل تترك مساحة دقيقة لإدخال المعلومات الموثقة.</p>
          </div>
        </div>
        <div class="card-grid">
          ${educatorCards.map(([tag, title, text]) => `
            <article class="profile-card">
              <span class="tag">${tag}</span>
              <h3>${title}</h3>
              <p>${text}</p>
            </article>
          `).join("")}
        </div>
      </div>
    </section>
    <section class="section band">
      <div class="container">
        <div class="section-header">
          <div>
            <h2>مسار السيرة</h2>
            <p>ترتيب مقترح لكل شخصية تربوية عند توفر المعلومات.</p>
          </div>
        </div>
        <div class="timeline">
          <article class="timeline-item"><span class="timeline-year">البداية</span><div><h3>النشأة والتعليم</h3><p>مكان الميلاد، الدراسة، وبداية العلاقة مع التعليم.</p></div></article>
          <article class="timeline-item"><span class="timeline-year">العطاء</span><div><h3>سنوات التدريس</h3><p>المدارس، المواد، المبادرات، والأنشطة التي شاركت بها الشخصية.</p></div></article>
          <article class="timeline-item"><span class="timeline-year">الأثر</span><div><h3>شهادات وذاكرة</h3><p>أقوال الطلاب والأهالي، وصور أو وثائق تدعم السيرة.</p></div></article>
        </div>
      </div>
    </section>
  `;
}

function initGalleryFilters() {
  const gallery = document.querySelector("[data-gallery]");
  if (!gallery) return;
  document.querySelectorAll("[data-gallery-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      const filter = button.dataset.galleryFilter;
      document.querySelectorAll("[data-gallery-filter]").forEach((item) => item.classList.toggle("active", item === button));
      gallery.querySelectorAll("[data-gallery-item]").forEach((item) => {
        item.hidden = filter !== "all" && item.dataset.galleryItem !== filter;
      });
    });
  });
}

function initMenu() {
  const header = document.querySelector("[data-header]");
  const toggle = document.querySelector("[data-menu-toggle]");
  if (!header || !toggle) return;
  toggle.addEventListener("click", () => {
    const open = header.classList.toggle("nav-open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      header.classList.remove("nav-open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

function initSubscribe() {
  const form = document.querySelector("[data-subscribe-form]");
  const note = document.querySelector("[data-form-note]");
  if (!form || !note) return;
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    note.textContent = "تم تسجيل طلب الاشتراك محليًا في هذه النسخة التجريبية.";
    form.reset();
  });
}

function initCopyWord() {
  const copyButton = document.querySelector("[data-copy-word]");
  const word = document.querySelector("[data-current-word]");
  if (!copyButton || !word) return;
  copyButton.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(word.textContent.trim());
      copyButton.textContent = "تم النسخ";
      window.setTimeout(() => {
        copyButton.textContent = "نسخ الكلمة";
      }, 1500);
    } catch {
      copyButton.textContent = word.textContent.trim();
    }
  });
}

function render() {
  buildNav();
  if (!app) return;

  if (currentPage === "home") {
    app.innerHTML = renderHome();
  } else if (currentPage === "magazine") {
    app.innerHTML = renderMagazine();
  } else if (currentPage === "photos") {
    app.innerHTML = renderPhotos();
  } else if (currentPage === "word") {
    app.innerHTML = renderWord();
  } else if (currentPage === "educators") {
    app.innerHTML = renderEducators();
  } else {
    app.innerHTML = renderStandardPage(pageData[currentPage] || pageData.news);
  }

  initGalleryFilters();
  initCopyWord();
}

buildNav();
initMenu();
initSubscribe();
render();
