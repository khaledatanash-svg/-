(function () {
  const articles = Array.isArray(window.MANARA_ARTICLES) ? window.MANARA_ARTICLES : [];
  const app = document.querySelector("#app");
  const page = document.body.dataset.page || "";

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function formatDate(value) {
    if (!value) return "";
    const date = new Date(`${value}T12:00:00`);
    if (Number.isNaN(date.getTime())) return escapeHtml(value);
    return new Intl.DateTimeFormat("ar", { year: "numeric", month: "long", day: "numeric" }).format(date);
  }

  function articleUrl(article) {
    return `article.html?slug=${encodeURIComponent(article.slug)}`;
  }

  function articleCard(article) {
    return `
      <article class="article-card publish-card">
        <div class="card-meta">
          <span class="tag">${escapeHtml(article.categoryLabel)}</span>
          <span class="meta-pill">${formatDate(article.date)}</span>
        </div>
        <h3>${escapeHtml(article.title)}</h3>
        <p>${escapeHtml(article.excerpt)}</p>
        <a class="button light" href="${articleUrl(article)}">قراءة المقال</a>
      </article>
    `;
  }

  function addArticlesNavLink() {
    const nav = document.querySelector("[data-nav]");
    if (!nav || nav.querySelector('a[href="articles.html"]')) return;
    const link = document.createElement("a");
    link.href = "articles.html";
    link.textContent = "مقالات";
    if (page === "articles" || page === "article") link.className = "active";
    nav.append(link);
  }

  function relatedArticles(category, limit = 3) {
    return articles
      .filter((article) => !category || article.category === category)
      .slice(0, limit);
  }

  function injectArticlesSection() {
    if (!app || !["home", "news", "culture", "arts", "heritage", "magazine"].includes(page)) return;
    const items = page === "home" ? articles.slice(0, 3) : relatedArticles(page, 3);
    if (!items.length) return;
    app.insertAdjacentHTML("beforeend", `
      <section class="section articles-section">
        <div class="container">
          <div class="section-header">
            <div>
              <h2>${page === "home" ? "آخر المقالات" : "مقالات منشورة"}</h2>
              <p>هذه المقالات تأتي من ملف النشر، ويمكن تعديلها وإضافة مقالات جديدة بسهولة.</p>
            </div>
            <a class="button light" href="articles.html">كل المقالات</a>
          </div>
          <div class="card-grid">
            ${items.map(articleCard).join("")}
          </div>
        </div>
      </section>
    `);
  }

  function renderArticlesIndex() {
    if (!app || page !== "articles") return;
    const categories = [...new Set(articles.map((article) => article.categoryLabel).filter(Boolean))];
    app.innerHTML = `
      <section class="page-hero">
        <div class="container">
          <p class="eyebrow">أرشيف النشر</p>
          <h1>مقالات</h1>
          <p class="lead">كل المقالات المنشورة في منارة حوارة الثقافية، مرتبة من ملف المقالات.</p>
        </div>
      </section>
      <section class="section">
        <div class="container">
          <div class="tag-list article-tags">
            ${categories.map((category) => `<span class="tag">${escapeHtml(category)}</span>`).join("")}
          </div>
          <div class="card-grid">
            ${articles.map(articleCard).join("") || `<p>لا توجد مقالات منشورة بعد.</p>`}
          </div>
        </div>
      </section>
    `;
  }

  function renderArticleDetail() {
    if (!app || page !== "article") return;
    const slug = new URLSearchParams(window.location.search).get("slug");
    const article = articles.find((item) => item.slug === slug);
    if (!article) {
      app.innerHTML = `
        <section class="page-hero">
          <div class="container">
            <p class="eyebrow">مقال غير موجود</p>
            <h1>لم نجد هذا المقال</h1>
            <p class="lead">قد يكون الرابط غير صحيح، أو أن المقال لم يعد موجودًا في ملف النشر.</p>
          </div>
        </section>
        <section class="section"><div class="container"><a class="button light" href="articles.html">العودة إلى المقالات</a></div></section>
      `;
      return;
    }

    document.title = `${article.title} | منارة حوارة الثقافية`;
    const body = Array.isArray(article.body) ? article.body : [];
    const tags = Array.isArray(article.tags) ? article.tags : [];
    app.innerHTML = `
      <article class="article-detail">
        <section class="page-hero article-detail-hero">
          <div class="container">
            <p class="eyebrow">${escapeHtml(article.categoryLabel)}</p>
            <h1>${escapeHtml(article.title)}</h1>
            <p class="lead">${escapeHtml(article.excerpt)}</p>
            <div class="article-meta">
              <span>${escapeHtml(article.author)}</span>
              <span>${formatDate(article.date)}</span>
            </div>
          </div>
        </section>
        <section class="section">
          <div class="container article-body">
            ${body.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join("")}
            <div class="tag-list">
              ${tags.map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join("")}
            </div>
            <div class="button-row article-actions">
              <a class="button light" href="articles.html">كل المقالات</a>
              <a class="button light" href="${escapeHtml(categoryHref(article.category))}">العودة للقسم</a>
            </div>
          </div>
        </section>
      </article>
    `;
  }

  function categoryHref(category) {
    const map = {
      news: "news.html",
      culture: "culture.html",
      arts: "arts.html",
      heritage: "heritage.html",
      magazine: "magazine.html"
    };
    return map[category] || "articles.html";
  }

  addArticlesNavLink();
  renderArticlesIndex();
  renderArticleDetail();
  injectArticlesSection();
})();
